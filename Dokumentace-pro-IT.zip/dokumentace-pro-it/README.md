# Dokumentace pro IT

Tento archiv obsahuje pouze dokumentaci a vzory konfigurace. Hotová aplikace, zdrojový kód a runtime jsou v samostatném archivu Kalkulacka-sluzeb-pro-IT.zip. Pro nasazení je potřeba také tento projektový balíček.

Začněte souborem NASAZENI.md (nebo stejným textem NASAZENI.txt). Žádná hesla ani provozní data nejsou součástí předání.
