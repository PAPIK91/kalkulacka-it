import { env } from 'cloudflare:workers';
import { defaultConfig, regionLabels, serviceLabels, upgradeConfig, validateConfig, type PricingConfig } from './pricing';
import { getChatGPTUser } from '../app/chatgpt-auth';
export type SettingsRow={id:number;config:string;version:number;owner_id:string;password_hash:string;salt:string;failures:number;locked_until:number;updated_at:string};
export function database(){if(!env.DB)throw new Error('Úložiště ceníku není dostupné.');return env.DB;}
export async function settings(){return database().prepare('SELECT * FROM settings WHERE id = 1').first<SettingsRow>();}
export function setupEnabled(){return env.ALLOW_ADMIN_SETUP === 'true';}
export async function identity(){return (await getChatGPTUser())?.userId ?? null;}
export function json(data:unknown,status=200){return Response.json(data,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});}
export function sameOrigin(req:Request){const origin=req.headers.get('origin');return !!origin&&origin===new URL(req.url).origin&&req.headers.get('content-type')?.includes('application/json');}
export async function body(req:Request){const text=await req.text();if(text.length>64000)throw new Error('Příliš velký požadavek.');return JSON.parse(text);}
export function hex(bytes:ArrayBuffer|Uint8Array){return Array.from(new Uint8Array(bytes instanceof ArrayBuffer?bytes:bytes.buffer as ArrayBuffer)).map(b=>b.toString(16).padStart(2,'0')).join('');}
export function random(){return hex(crypto.getRandomValues(new Uint8Array(32)));}
export async function digest(value:string){return hex(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value)));}
export async function passwordHash(password:string,salt:string){const material=await crypto.subtle.importKey('raw',new TextEncoder().encode(password),'PBKDF2',false,['deriveBits']);return hex(await crypto.subtle.deriveBits({name:'PBKDF2',hash:'SHA-256',salt:new TextEncoder().encode(salt),iterations:100000},material,256));}
export function equal(a:string,b:string){let different=a.length^b.length;for(let i=0;i<Math.max(a.length,b.length);i++)different|=(a.charCodeAt(i)||0)^(b.charCodeAt(i)||0);return different===0;}
export function cookieToken(req:Request){return req.headers.get('cookie')?.split(';').map(v=>v.trim()).find(v=>v.startsWith('pricing_session='))?.slice(16)??'';}
export async function isAdmin(req:Request,row:SettingsRow|null){if(!row)return false;const token=cookieToken(req);if(!/^[a-f0-9]{64}$/.test(token))return false;const found=await database().prepare('SELECT owner_id FROM sessions WHERE token_hash = ? AND expires_at > ?').bind(await digest(token),Date.now()).first<{owner_id:string}>();return found?.owner_id===row.owner_id;}
export async function configResponse(req:Request){const row=await settings();const userId=await identity();return json({config:row?upgradeConfig(JSON.parse(row.config)):defaultConfig,version:row?.version??0,admin:await isAdmin(req,row),setupRequired:!row,setupAvailable:setupEnabled()&&!!userId,reviewRequired:true});}
export function validConfig(config:unknown){return validateConfig(config);}
function flatten(value:unknown,path:string[]=[]):Map<string,unknown>{
 const out=new Map<string,unknown>();
 if(value&&typeof value==='object'&&!Array.isArray(value))for(const [key,item] of Object.entries(value))for(const [childPath,childValue] of flatten(item,[...path,key]))out.set(childPath,childValue);
 else out.set(path.join('.'),value);
 return out;
}
function auditLabel(path:string){
 const p=path.split('.');
 if(p[0]==='fuelPercent')return 'Palivový příplatek';
 if(p[0]==='clientPaymentMultiplier')return 'Koeficient doplatku klientovi';
 if(p[0]==='regions'&&p.length>=3){
  const region=p[1] as keyof typeof regionLabels;const prefix=`${regionLabels[region]||region} (${region==='sk'||region==='abroad_sk'?'EUR':'CZK'})`;
  if(p[2]==='includedKm')return `${prefix} — kilometry v paušálu`;
  if(p[2]==='vatPercent')return `${prefix} — sazba DPH`;
  if(p[2]==='tariffs'&&p.length===5){const service=p[3] as keyof typeof serviceLabels;return `${prefix} — ${serviceLabels[service]||service}, ${p[4]==='base'?'paušál':'sazba za km'}`;}
  if(p[2]==='extras'&&p.length===4){const labels:Record<string,string>={recovery:'Vyproštění / 30 min',manipulation:'Ztížená manipulace / 30 min',waiting:'Čekání / 30 min',storage:'Úschova / den',coveredStorage:'Krytá úschova / den',mechanicDpv:'Práce mechanika — DPV / 30 min',mechanicUnlock:'Práce mechanika — Odemčení / 30 min',night:'Noční příplatek',weekend:'Víkend / svátek',trolleyOne:'Vozíček 1 ks',trolleyMultiple:'Vozíčky 2 a více',glasses:'Brýle'};return `${prefix} — ${labels[p[3]]||p[3]}`;}
 }
 return path;
}
export function configChanges(previous:unknown,next:unknown){
 const before=flatten(upgradeConfig(previous));const after=flatten(upgradeConfig(next));
 return [...new Set([...before.keys(),...after.keys()])].filter(path=>path!=='version'&&JSON.stringify(before.get(path))!==JSON.stringify(after.get(path))).map(path=>({path,label:auditLabel(path),oldValue:before.get(path)??null,newValue:after.get(path)??null}));
}
export type {PricingConfig};
