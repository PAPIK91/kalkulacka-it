/** Ceník převzatý z Jotformu 26. 10. 2026. Výpočty se neopírají o historii formuláře. */
export type DomesticRegion = 'cz' | 'cities' | 'sk';
export type Region = DomesticRegion | 'abroad_cz' | 'abroad_sk';
export type Service = 'standard' | 'oversize' | 'hydraulic' | 'dpv' | 'unlock';
export type Extras = { recovery: number; manipulation: number; waiting: number; storage: number; coveredStorage: number; mechanicDpv: number; mechanicUnlock: number; night: number; weekend: number; trolleyOne: number; trolleyMultiple: number; glasses: number };
export type RegionConfig = { currency: 'CZK' | 'EUR'; includedKm: number; vatPercent: number; tariffs: Record<Service, { base: number; perKm: number }>; extras: Extras };
export type PricingConfig = { version: number; fuelPercent: number; clientPaymentMultiplier: number; regions: Record<DomesticRegion, RegionConfig> };
export type PricingInput = { region: Region; service: Service; distanceMode: 'total' | 'extra'; distance: number; recoveryMinutes: number; manipulationMinutes: number; waitingMinutes: number; mechanicMinutes: number; storageDays: number; coveredStorage: boolean; night: boolean; weekend: boolean; trolleys: 'none' | 'one' | 'multiple'; glasses: boolean; transfer: boolean; transferExtraKm: number; toll: number; otherName: string; otherPrice: number; fuel: boolean; gop: number; abroadMode: 'flat' | 'hourly'; abroadFlatRate: number; abroadHourlyRate: number; abroadHours: number; abroadPerKm: number };
export type CalculationInput = PricingInput;
export type BreakdownLine = { id: string; label: string; quantity: number; unitPrice: number; total: number };
export type CalculationResult = { currency: 'CZK' | 'EUR'; breakdown: BreakdownLine[]; base: number; perKm: number; includedKm: number; extraKm: number; subtotal: number; fuel: number; net: number; vat: number; gross: number; clientPayment: number; summary: string; warnings: string[] };
export const regionLabels: Record<Region, string> = { cz: 'CZ', cities: 'Praha, Brno', sk: 'SK', abroad_cz: 'Zahraničí CZ', abroad_sk: 'Zahraničí SK' };
export const serviceLabels: Record<Service, string> = { standard: 'RMQ · Standard', oversize: 'RMQ · Nadrozměr', hydraulic: 'RMQ · Hydraulika', dpv: 'DPV', unlock: 'Odemčení vozidla' };
const czExtras: Extras = { recovery: 900, manipulation: 350, waiting: 210, storage: 105, coveredStorage: 160, mechanicDpv: 0, mechanicUnlock: 0, night: 550, weekend: 300, trolleyOne: 500, trolleyMultiple: 750, glasses: 500 };
const skExtras: Extras = { recovery: 36, manipulation: 20, waiting: 12, storage: 6, coveredStorage: 7, mechanicDpv: 0, mechanicUnlock: 0, night: 24, weekend: 14, trolleyOne: 22, trolleyMultiple: 32, glasses: 22 };
export const defaultConfig: PricingConfig = {
  version: 1, fuelPercent: 5, clientPaymentMultiplier: 1.2,
  regions: {
    cz: { currency: 'CZK', includedKm: 35, vatPercent: 21, extras: { ...czExtras }, tariffs: { standard: { base: 1350, perKm: 25 }, oversize: { base: 1600, perKm: 27 }, hydraulic: { base: 2300, perKm: 28 }, dpv: { base: 1200, perKm: 19 }, unlock: { base: 2200, perKm: 19 } } },
    cities: { currency: 'CZK', includedKm: 45, vatPercent: 21, extras: { ...czExtras }, tariffs: { standard: { base: 1550, perKm: 25 }, oversize: { base: 1800, perKm: 27 }, hydraulic: { base: 2550, perKm: 28 }, dpv: { base: 1300, perKm: 19 }, unlock: { base: 2200, perKm: 19 } } },
    sk: { currency: 'EUR', includedKm: 35, vatPercent: 23, extras: { ...skExtras }, tariffs: { standard: { base: 58, perKm: 1.05 }, oversize: { base: 70, perKm: 1.15 }, hydraulic: { base: 95, perKm: 1.2 }, dpv: { base: 48, perKm: .8 }, unlock: { base: 88, perKm: .8 } } },
  },
};
export const defaultInput: PricingInput = { region: 'cz', service: 'standard', distanceMode: 'total', distance: 0, recoveryMinutes: 0, manipulationMinutes: 0, waitingMinutes: 0, mechanicMinutes: 0, storageDays: 0, coveredStorage: false, night: false, weekend: false, trolleys: 'none', glasses: false, transfer: false, transferExtraKm: 0, toll: 0, otherName: '', otherPrice: 0, fuel: false, gop: 0, abroadMode: 'flat', abroadFlatRate: 0, abroadHourlyRate: 0, abroadHours: 0, abroadPerKm: 0 };
const domesticRegions: DomesticRegion[] = ['cz', 'cities', 'sk'];
const regions: Region[] = [...domesticRegions, 'abroad_cz', 'abroad_sk'];
export const isAbroad = (region: Region): boolean => region === 'abroad_cz' || region === 'abroad_sk';
export function getRegionConfig(config: PricingConfig, region: Region): RegionConfig {
  return config.regions[region === 'abroad_cz' ? 'cz' : region === 'abroad_sk' ? 'sk' : region];
}
/** Add zero-valued mechanic rates when reading ceníky saved by older versions. */
export function upgradeConfig(value: unknown): PricingConfig {
  if (!record(value) || !record(value.regions)) return value as PricingConfig;
  const upgraded = { ...value, regions: { ...value.regions } } as Record<string, unknown>;
  for (const key of domesticRegions) {
    const region = value.regions[key];
    if (!record(region) || !record(region.extras)) continue;
    upgraded.regions = { ...(upgraded.regions as Record<string, unknown>), [key]: { ...region, extras: { ...defaultConfig.regions[key].extras, ...region.extras } } };
  }
  return upgraded as unknown as PricingConfig;
}
const services: Service[] = ['standard', 'oversize', 'hydraulic', 'dpv', 'unlock'];
const extraKeys: (keyof Extras)[] = ['recovery', 'manipulation', 'waiting', 'storage', 'coveredStorage', 'mechanicDpv', 'mechanicUnlock', 'night', 'weekend', 'trolleyOne', 'trolleyMultiple', 'glasses'];
const record = (value: unknown): value is Record<string, unknown> => typeof value === 'object' && value !== null && !Array.isArray(value);
const decimal = (value: unknown, max = 1_000_000): value is number => typeof value === 'number' && Number.isFinite(value) && value >= 0 && value <= max && Number(value.toFixed(2)) === value;
function keys(value: Record<string, unknown>, expected: string[], path: string, errors: string[]) {
  for (const key of Object.keys(value)) if (!expected.includes(key)) errors.push(`${path}: neznámý parametr ${key}.`);
}
export function validateConfig(value: unknown): string[] {
  const errors: string[] = [];
  if (!record(value)) return ['Ceník musí být objekt.'];
  keys(value, ['version', 'fuelPercent', 'clientPaymentMultiplier', 'regions'], 'Ceník', errors);
  if (!Number.isSafeInteger(value.version) || (value.version as number) < 1) errors.push('Neplatná verze ceníku.');
  if (!decimal(value.fuelPercent, 100)) errors.push('Palivový příplatek musí být od 0 do 100 %.');
  if (!decimal(value.clientPaymentMultiplier, 10)) errors.push('Koeficient doplatku musí být od 0 do 10.');
  if (!record(value.regions)) return [...errors, 'Chybí regionální ceníky.'];
  keys(value.regions, domesticRegions, 'Regiony', errors);
  for (const region of domesticRegions) {
    const item = value.regions[region];
    if (!record(item)) { errors.push(`Chybí ceník ${regionLabels[region]}.`); continue; }
    keys(item, ['currency', 'includedKm', 'vatPercent', 'tariffs', 'extras'], region, errors);
    if (item.currency !== (region === 'sk' ? 'EUR' : 'CZK')) errors.push(`${region}: nesprávná měna.`);
    if (!decimal(item.includedKm, 100_000)) errors.push(`${region}: neplatný limit km.`);
    if (!decimal(item.vatPercent, 100)) errors.push(`${region}: DPH musí být od 0 do 100 %.`);
    if (!record(item.tariffs)) errors.push(`${region}: chybí tarify.`);
    else {
      keys(item.tariffs, services, `${region}.tariffs`, errors);
      for (const service of services) {
        const tariff = item.tariffs[service];
        if (!record(tariff)) { errors.push(`${region}/${service}: chybí tarif.`); continue; }
        keys(tariff, ['base', 'perKm'], `${region}/${service}`, errors);
        if (!decimal(tariff.base) || !decimal(tariff.perKm)) errors.push(`${region}/${service}: sazby musí být nezáporná čísla do 1 000 000 s nejvýše 2 desetinnými místy.`);
      }
    }
    if (!record(item.extras)) errors.push(`${region}: chybí příplatky.`);
    else {
      keys(item.extras, extraKeys, `${region}.extras`, errors);
      for (const key of extraKeys) if (!decimal(item.extras[key])) errors.push(`${region}/${key}: neplatná sazba.`);
    }
  }
  return errors;
}
export function validateInput(value: unknown): string[] {
  if (!record(value)) return ['Vstup kalkulace musí být objekt.'];
  const errors: string[] = [];
  keys(value, Object.keys(defaultInput), 'Kalkulace', errors);
  if (!regions.includes(value.region as Region)) errors.push('Vyberte platný region.');
  const abroad = isAbroad(value.region as Region);
  if (!abroad && !services.includes(value.service as Service)) errors.push('Vyberte platnou službu.');
  if (!abroad && value.distanceMode !== 'total' && value.distanceMode !== 'extra') errors.push('Vyberte režim kilometrů.');
  if (abroad) {
    if (value.abroadMode !== 'flat' && value.abroadMode !== 'hourly') errors.push('Vyberte paušál nebo hodinovou sazbu.');
    for (const key of ['abroadFlatRate', 'abroadHourlyRate', 'abroadHours', 'abroadPerKm']) if (!decimal(value[key])) errors.push(`${key}: zadejte nezáporné číslo do 1 000 000 s nejvýše 2 desetinnými místy.`);
  }
  for (const key of abroad ? ['distance', 'otherPrice', 'gop'] : ['distance', 'transferExtraKm', 'toll', 'otherPrice', 'gop']) if (!decimal(value[key])) errors.push(`${key}: zadejte nezáporné číslo do 1 000 000 s nejvýše 2 desetinnými místy.`);
  if (!abroad) {
  for (const key of ['recoveryMinutes', 'manipulationMinutes', 'waitingMinutes']) if (!Number.isInteger(value[key]) || (value[key] as number) < 0 || (value[key] as number) > 300 || (value[key] as number) % 30 !== 0) errors.push(`${key}: čas musí být od 0 do 300 minut po 30 minutách.`);
  if (!Number.isInteger(value.mechanicMinutes) || (value.mechanicMinutes as number) < 0 || (value.mechanicMinutes as number) > 300 || (value.mechanicMinutes as number) % 30 !== 0) errors.push('Práce mechanika musí být od 0 do 300 minut po 30 minutách.');
  if (!Number.isInteger(value.storageDays) || (value.storageDays as number) < 0 || (value.storageDays as number) > 60) errors.push('Úschova musí být od 0 do 60 dní.');
  for (const key of ['coveredStorage', 'night', 'weekend', 'glasses', 'transfer', 'fuel']) if (typeof value[key] !== 'boolean') errors.push(`${key}: neplatná volba.`);
  if (!['none', 'one', 'multiple'].includes(value.trolleys as string)) errors.push('Vyberte platný počet vozíčků.');
  }
  if (typeof value.otherName !== 'string' || value.otherName.length > 200) errors.push('Název jiné služby může mít nejvýše 200 znaků.');
  if (typeof value.otherPrice === 'number' && value.otherPrice > 0 && (typeof value.otherName !== 'string' || !value.otherName.trim())) errors.push('Doplňte název jiné služby.');
  return errors;
}
// Vstupy mají nejvýše dvě desetinná místa. Výpočet probíhá v celých haléřích/centech.
// BigInt zachovává přesnost i pro vysoké ceny a vzdálenosti. Půlení: od nuly.
const minor = (value: number) => BigInt(Math.round(value * 100));
function divideRounded(numerator: bigint, denominator: bigint): bigint {
  const sign = numerator < BigInt(0) ? BigInt(-1) : BigInt(1);
  const absolute = numerator * sign;
  return sign * ((absolute + denominator / BigInt(2)) / denominator);
}
const amount = (value: bigint) => Number(value) / 100;
const multiply = (price: number, quantity: number) => divideRounded(minor(price) * minor(quantity), BigInt(100));
export function calculate(input: PricingInput, config: PricingConfig = defaultConfig): CalculationResult {
  const errors = [...validateInput(input), ...validateConfig(config)];
  if (errors.length) throw new Error(errors.join(' '));
  const abroad = isAbroad(input.region);
  const region = getRegionConfig(config, input.region);
  const tariff = abroad ? { base: input.abroadMode === 'flat' ? input.abroadFlatRate : amount(multiply(input.abroadHourlyRate, input.abroadHours)), perKm: input.abroadPerKm } : region.tariffs[input.service];
  const extraKm = abroad ? input.distance : amount(input.distanceMode === 'extra' ? minor(input.distance) : (minor(input.distance) > minor(region.includedKm) ? minor(input.distance) - minor(region.includedKm) : BigInt(0)));
  const breakdown: BreakdownLine[] = [];
  const line = (id: string, label: string, quantity: number, unitPrice: number, force = false) => {
    if (quantity > 0 || force) breakdown.push({ id, label, quantity, unitPrice, total: amount(multiply(unitPrice, quantity)) });
  };
  if (abroad) {
    if (input.abroadMode === 'flat') line('base', 'Paušál', 1, input.abroadFlatRate, true);
    else line('hourly', 'Práce — hodinová sazba', input.abroadHours, input.abroadHourlyRate, true);
    line('distance', 'Doprava — kilometry', input.distance, input.abroadPerKm);
  } else {
  line('base', `Paušál · ${serviceLabels[input.service]}`, 1, tariff.base, true);
  line('distance', 'Kilometry nad paušál', extraKm, tariff.perKm);
  if (input.service === 'dpv' || input.service === 'unlock') {
    const mechanicRate = input.service === 'dpv' ? region.extras.mechanicDpv : region.extras.mechanicUnlock;
    line('mechanic', 'Práce mechanika na místě (30 minut)', input.mechanicMinutes / 30, mechanicRate);
  } else {
  line('recovery', 'Vyproštění (30 minut)', input.recoveryMinutes / 30, region.extras.recovery);
  line('manipulation', 'Ztížená manipulace (30 minut)', input.manipulationMinutes / 30, region.extras.manipulation);
  line('waiting', 'Čekání (30 minut)', input.waitingMinutes / 30, region.extras.waiting);
  line('storage', input.coveredStorage ? 'Úschova na kryté ploše (den)' : 'Úschova (den)', input.storageDays, input.coveredStorage ? region.extras.coveredStorage : region.extras.storage);
  }
  line('night', 'Noční příplatek', input.night ? 1 : 0, region.extras.night);
  line('weekend', 'Víkend / státní svátek', input.weekend ? 1 : 0, region.extras.weekend);
  line('trolleys', input.trolleys === 'one' ? 'Vozíček 1 ks' : 'Vozíčky 2 a více', input.trolleys === 'none' ? 0 : 1, input.trolleys === 'one' ? region.extras.trolleyOne : region.extras.trolleyMultiple);
  line('glasses', 'Brýle', input.glasses ? 1 : 0, region.extras.glasses);
  if (input.transfer) {
    line('transfer-base', 'Přetah · paušál', 1, tariff.base, true);
    line('transfer-distance', 'Přetah · kilometry nad paušál', input.transferExtraKm, tariff.perKm);
  }
  line('toll', 'Mýto', input.toll > 0 ? 1 : 0, input.toll);
  }
  line('other', input.otherName.trim(), input.otherPrice > 0 ? 1 : 0, input.otherPrice);
  const subtotalMinor = breakdown.reduce((sum, item) => sum + minor(item.total), BigInt(0));
  const fuelMinor = !abroad && input.fuel ? divideRounded(subtotalMinor * minor(config.fuelPercent), BigInt(10000)) : BigInt(0);
  const netMinor = subtotalMinor + fuelMinor;
  const vatMinor = divideRounded(netMinor * minor(region.vatPercent), BigInt(10000));
  const grossMinor = netMinor + vatMinor;
  const unpaidMinor = grossMinor > minor(input.gop) ? grossMinor - minor(input.gop) : BigInt(0);
  const paymentMinor = divideRounded(unpaidMinor * minor(config.clientPaymentMultiplier), BigInt(100));
  const format = (value: number) => new Intl.NumberFormat('cs-CZ', { style: 'currency', currency: region.currency, minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(value).replace(/[\u00a0\u202f]/g, ' ');
  const number = (value: number, minimumFractionDigits = 0) => new Intl.NumberFormat('cs-CZ', { minimumFractionDigits, maximumFractionDigits: 2 }).format(value).replace(/[\u00a0\u202f]/g, ' ');
  const oneLine = (value: string) => value.replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim();
  const quantityLines = ['hourly', 'distance', 'recovery', 'manipulation', 'waiting', 'mechanic', 'storage', 'transfer-distance'];
  const summary = [
    'KALKULACE SLUŽEB',
    `Region: ${regionLabels[input.region]}`,
    ...(abroad ? [
      `Režim: ${input.abroadMode === 'flat' ? 'Paušál' : 'Hodinová sazba'}`,
      ...(input.abroadMode === 'flat' ? [`Zadaný paušál: ${format(input.abroadFlatRate)}`] : [`Počet hodin: ${number(input.abroadHours)} h`, `Hodinová sazba: ${format(input.abroadHourlyRate)} / h`]),
      `Celková trasa: ${number(input.distance)} km`,
      `Sazba za kilometr: ${format(input.abroadPerKm)} / km`,
    ] : [
      `Služba: ${serviceLabels[input.service]}`,
      input.distanceMode === 'total' ? `Celková trasa: ${number(input.distance)} km` : `Manuálně zadané kilometry nad paušál: ${number(input.distance)} km`,
      `Paušál zahrnuje: ${number(region.includedKm)} km`,
      `Účtované kilometry nad paušál: ${number(extraKm)} km`,
    ]),
    '',
    'POLOŽKY BEZ DPH',
    ...breakdown.map(item => `${oneLine(item.label)}: ${item.quantity !== 1 || quantityLines.includes(item.id) ? `${number(item.quantity)} × ${format(item.unitPrice)} = ` : ''}${format(item.total)}`),
    '',
    `Součet služeb: ${format(amount(subtotalMinor))}`,
    ...(!abroad ? [input.fuel ? `Palivový příplatek (${number(config.fuelPercent)} %): ${format(amount(fuelMinor))}` : 'Palivový příplatek: neúčtován'] : []),
    `Celkem bez DPH: ${format(amount(netMinor))}`,
    `DPH (${number(region.vatPercent)} %): ${format(amount(vatMinor))}`,
    `CELKEM S DPH: ${format(amount(grossMinor))}`,
    '',
    `GOP – hrazená částka: ${format(input.gop)}`,
    ...(paymentMinor > BigInt(0) ? [`Doplatek klientovi (koeficient ${number(config.clientPaymentMultiplier, 2)}): ${format(amount(paymentMinor))}`] : []),
  ].join('\n');
  return { currency: region.currency, breakdown, base: tariff.base, perKm: tariff.perKm, includedKm: abroad ? 0 : region.includedKm, extraKm, subtotal: amount(subtotalMinor), fuel: amount(fuelMinor), net: amount(netMinor), vat: amount(vatMinor), gross: amount(grossMinor), clientPayment: amount(paymentMinor), summary, warnings: ['Koeficient doplatku je převzatý ze zdroje; jeho obchodní význam a pravidla zaokrouhlení čekají na potvrzení.'] };
}
