import {database,isAdmin,json,settings} from '../../../lib/server-pricing';
export const dynamic='force-dynamic';
export async function GET(req:Request){
 try{
  const row=await settings();if(!await isAdmin(req,row))return json({error:'Pro zobrazení historie se přihlaste jako správce.'},401);
  const result=await database().prepare('SELECT id,actor,changed_at,version,changes FROM price_audit ORDER BY id DESC LIMIT 500').all<{id:number;actor:string;changed_at:string;version:number;changes:string}>();
  return json({entries:result.results.map(entry=>({...entry,changes:JSON.parse(entry.changes)}))});
 }catch{return json({error:'Historii změn se nepodařilo načíst.'},503);}
}
