import { json } from '../../../lib/server-pricing';

export const dynamic = 'force-dynamic';
const RATE_URL = 'https://www.cnb.cz/cs/financni-trhy/devizovy-trh/kurzy-devizoveho-trhu/kurzy-devizoveho-trhu/denni_kurz.txt';
let cached: { rate: number; date: string; fetchedAt: number } | null = null;

export async function GET() {
  if (cached && Date.now() - cached.fetchedAt < 30 * 60 * 1000) {
    return json({ rate: cached.rate, date: cached.date, source: 'ČNB' });
  }
  try {
    const response = await fetch(RATE_URL, { cache: 'no-store', signal: AbortSignal.timeout(8000) });
    if (!response.ok) return json({ error: 'Aktuální kurz ČNB se nepodařilo načíst.' }, 502);
    const lines = (await response.text()).split(/\r?\n/);
    const date = lines[0]?.match(/^(\d{2}\.\d{2}\.\d{4})/)?.[1];
    const row = lines.find(line => line.split('|')[3] === 'EUR')?.split('|');
    const rate = Number(row?.[4]?.replace(',', '.'));
    if (!date || !Number.isFinite(rate) || rate <= 0) return json({ error: 'Kurz EUR v datech ČNB chybí.' }, 502);
    cached = { rate, date, fetchedAt: Date.now() };
    return json({ rate, date, source: 'ČNB' });
  } catch {
    return json({ error: 'ČNB nyní neodpovídá. Zkuste kurz načíst později.' }, 502);
  }
}
