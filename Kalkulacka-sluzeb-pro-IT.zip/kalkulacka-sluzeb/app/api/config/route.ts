import {body,configChanges,configResponse,database,isAdmin,json,sameOrigin,settings,validConfig} from '../../../lib/server-pricing';
export const dynamic='force-dynamic';
export async function GET(req:Request){try{return await configResponse(req);}catch{return json({error:'Ceník se nepodařilo načíst.'},503);}}
export async function PUT(req:Request){try{
 if(!sameOrigin(req))return json({error:'Neplatný původ požadavku.'},403);
 const row=await settings();if(!await isAdmin(req,row))return json({error:'Pro úpravy se přihlaste jako správce.'},401);
 const {config,version,actor}=await body(req);const errors=validConfig(config);if(errors.length)return json({error:errors.join(' ')},400);
 const actorName=typeof actor==='string'?actor.replace(/[\u0000-\u001f\u007f]/g,' ').replace(/\s+/g,' ').trim():'';
 if(!actorName||actorName.length>80)return json({error:'Zadejte jméno nebo přezdívku (max. 80 znaků).'},400);
 if(!Number.isSafeInteger(version))return json({error:'Neplatná verze ceníku.'},400);
 if(!row)return json({error:'Ceník není inicializován.'},409);
 const previous=JSON.parse(row.config);const changes=configChanges(previous,config);if(!changes.length)return json({error:'Ceník neobsahuje žádnou změnu.'},400);
 const next=version+1;const updatedConfig=JSON.stringify({...config,version:next});const changedAt=new Date().toISOString();
 const results=await database().batch([
  database().prepare('UPDATE settings SET config = ?, version = ?, updated_at = ? WHERE id = 1 AND version = ?').bind(updatedConfig,next,changedAt,version),
  database().prepare('INSERT INTO price_audit(actor,changed_at,version,changes) SELECT ?,?,?,? WHERE changes() = 1').bind(actorName,changedAt,next,JSON.stringify(changes)),
 ]);
 if(results[0]?.meta?.changes!==1)return json({error:'Ceník mezitím někdo změnil. Obnovte stránku a úpravu opakujte.'},409);
 return await configResponse(req);
 }catch{return json({error:'Změnu ceníku se nepodařilo uložit.'},400);}}
