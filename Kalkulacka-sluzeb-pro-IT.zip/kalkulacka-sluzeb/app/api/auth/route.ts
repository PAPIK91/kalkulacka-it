import {defaultConfig} from '../../../lib/pricing';
import {body,cookieToken,database,digest,equal,identity,json,passwordHash,random,sameOrigin,settings,setupEnabled} from '../../../lib/server-pricing';
export const dynamic='force-dynamic';
const ttl=8*60*60*1000;
function cookie(req:Request,token:string,seconds:number){return `pricing_session=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${seconds}${new URL(req.url).protocol==='https:'?'; Secure':''}`;}
export async function POST(req:Request){try{
 if(!sameOrigin(req))return json({error:'Neplatný původ požadavku.'},403);
 const {action,password}=await body(req);
 let ownerId:string;
 if(action==='logout'){const token=cookieToken(req);if(token)await database().prepare('DELETE FROM sessions WHERE token_hash = ?').bind(await digest(token)).run();const response=json({ok:true});response.headers.set('Set-Cookie',cookie(req,'',0));return response;}
 if(action!=='setup'&&action!=='login')return json({error:'Neplatná operace.'},400);
 if(typeof password!=='string'||password.length<12||password.length>256)return json({error:'Heslo musí obsahovat 12 až 256 znaků.'},400);
 const row=await settings();
 if(action==='setup'){
  if(!setupEnabled())return json({error:'První nastavení správce není na veřejném webu povolené.'},403);
  const user=await identity();
  if(!user)return json({error:'První nastavení hesla správce vyžaduje ověřeného vlastníka.'},403);
  ownerId=user;
  if(row)return json({error:'Heslo správce je již nastavené.'},409);
  const salt=random();const hash=await passwordHash(password,salt);
  const inserted=await database().prepare('INSERT OR IGNORE INTO settings (id,config,version,owner_id,password_hash,salt,failures,locked_until,updated_at) VALUES (1,?,1,?,?,?,0,0,?)').bind(JSON.stringify({...defaultConfig,version:1}),user,hash,salt,new Date().toISOString()).run();
  if(inserted.meta.changes!==1)return json({error:'Správce již byl nastaven.'},409);
 }else{
  if(!row)return json({error:'Přístup správce zatím není nastavený.'},403);
  ownerId=row.owner_id;
  if(row.locked_until>Date.now())return json({error:'Příliš mnoho pokusů. Zkuste to za 15 minut.'},429);
  const now=Date.now();
  const reserved=await database().prepare('UPDATE settings SET failures = CASE WHEN locked_until > 0 THEN 1 ELSE failures + 1 END, locked_until = CASE WHEN locked_until > 0 THEN 0 WHEN failures >= 4 THEN ? ELSE 0 END WHERE id = 1 AND locked_until <= ?').bind(now+15*60*1000,now).run();
  if(reserved.meta.changes!==1)return json({error:'Příliš mnoho pokusů. Zkuste to za 15 minut.'},429);
  if(!equal(await passwordHash(password,row.salt),row.password_hash))return json({error:'Nesprávné heslo.'},401);
  await database().prepare('UPDATE settings SET failures = 0, locked_until = 0 WHERE id = 1').run();
 }
 await database().prepare('DELETE FROM sessions WHERE expires_at <= ?').bind(Date.now()).run();
 const token=random();await database().prepare('INSERT INTO sessions (token_hash,owner_id,expires_at) VALUES (?,?,?)').bind(await digest(token),ownerId,Date.now()+ttl).run();const response=json({ok:true});response.headers.set('Set-Cookie',cookie(req,token,ttl/1000));return response;
}catch{return json({error:'Přihlášení se nepodařilo dokončit.'},400);}}
