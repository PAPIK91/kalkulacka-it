import {calculate,defaultConfig,validateInput} from '../../../lib/pricing';
import {body,json,sameOrigin,settings} from '../../../lib/server-pricing';
export const dynamic='force-dynamic';
export async function POST(req:Request){try{if(!sameOrigin(req))return json({error:'Neplatný původ požadavku.'},403);const {input}=await body(req);const errors=validateInput(input);if(errors.length)return json({error:errors.join(' ')},400);const row=await settings();return json({...calculate(input,row?JSON.parse(row.config):defaultConfig),version:row?.version??0,reviewRequired:true});}catch{return json({error:'Výpočet se nepodařilo dokončit.'},400);}}
