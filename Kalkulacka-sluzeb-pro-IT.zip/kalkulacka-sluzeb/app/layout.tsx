import type { Metadata } from "next";
import "./globals.css";
export const metadata:Metadata={title:"Kalkulačka služeb",description:"Pracovní kalkulačka nákladů za služby a správa ceníku."};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="cs"><body>{children}</body></html>}
