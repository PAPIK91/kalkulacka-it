declare namespace Cloudflare {
  interface Env {
    DB?: D1Database;
    ALLOW_ADMIN_SETUP?: string;
    BUCKET?: R2Bucket;
  }
}
