# Ověření předávané verze

Datum: 26. 10. 2026. Balíček obsahuje aktuální zdroje a hotový runtime se zahraničními regiony, přehledným UZ, vyšším kontrastem a nezáporným doplatkem.

- Aktuální sestavení aplikace ze zdrojů: úspěšné před nasazením.
- Aktuální TypeScript kontrola: bez chyb.
- 61 testů cenového jádra: úspěšné. Zahrnují původní tarify, kilometrové hranice, příplatky, zahraniční paušál/hodiny/km, CZK/EUR a DPH, skryté neúčtované služby, UZ a doplatek při GOP pod/rovno/nad výslednou cenou.
- 18 kontrol Node/SQLite runtime: úspěšné při posledním sestavení.
- 21 HTTP kontrol: úspěšné v předchozím ověření self-host serveru. Po posledních změnách nebyl celý tento HTTP soubor testů znovu spuštěný; nejde o tvrzení aktuálního úplného opakování.

Ověření nezahrnuje konkrétní firemní infrastrukturu, její proxy a přístupová pravidla. Obchodní význam koeficientu, přetahu a zaokrouhlování vyžaduje potvrzení vlastníka podle NASAZENI.md.
