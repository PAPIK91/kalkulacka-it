# Ověření předávané verze

Datum: 29. 10. 2026. Balíček obsahuje práci mechanika pro DPV a Odemčení, zahraniční regiony, přehledný UZ, vyšší kontrast a nezáporný doplatek.

- Sestavení aktuální self-host verze: úspěšné.
- TypeScript kontrola aktuálních zdrojů: bez chyb.
- 61 cenových testů bylo úspěšných před přidáním práce mechanika; nepokrývají novou sazbu.
- 18 kontrol Node/SQLite runtime bylo úspěšných při dřívějším sestavení; po této změně nebyly znovu spuštěny.
- 21 HTTP kontrol bylo úspěšných při předchozím ověření self-host serveru; po následných změnách nebyly znovu spuštěny.

Ověření nezahrnuje konkrétní firemní infrastrukturu, její proxy a přístupová pravidla. Obchodní význam koeficientu, přetahu a zaokrouhlování vyžaduje potvrzení vlastníka podle NASAZENI.md.
