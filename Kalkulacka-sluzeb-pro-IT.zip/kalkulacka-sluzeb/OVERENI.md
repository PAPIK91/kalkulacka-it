# Ověření předávané verze

Datum: 6. 11. 2026. Balíček obsahuje potvrzování změn ceníku jménem/přezdívkou a heslem chráněnou historii, práci mechanika pro DPV a Odemčení, zahraniční regiony, marné paušály, přehledný UZ a nezáporný doplatek.

- TypeScript kontrola a sestavení self-host verze (6. 11. 2026): úspěšné. Nasazení této verze na produkční server čeká na obnovení SSH připojení.
- Testovací sady nebyly spuštěny po přidání marných paušálů.
- 61 cenových testů bylo úspěšných před přidáním práce mechanika; nepokrývají tuto ani novou auditní funkci.
- 18 kontrol Node/SQLite runtime bylo úspěšných při dřívějším sestavení; po této změně nebyly znovu spuštěny.
- 21 HTTP kontrol bylo úspěšných při předchozím ověření self-host serveru; po následných změnách nebyly znovu spuštěny.

Ověření nezahrnuje konkrétní firemní infrastrukturu, její proxy a přístupová pravidla. Obchodní význam koeficientu, přetahu a zaokrouhlování vyžaduje potvrzení vlastníka podle NASAZENI.md.
