# Ověření předávané verze

Datum: 29. 10. 2026. Balíček obsahuje potvrzování změn ceníku jménem/přezdívkou a heslem chráněnou historii, práci mechanika pro DPV a Odemčení, zahraniční regiony, přehledný UZ a nezáporný doplatek.

- Sestavení self-host verze s historií změn (29. 10. 2026): úspěšné; nasazení na kalkulacka.ppsound.cz vrací HTTP 200.
- TypeScript kontrola aktuálních zdrojů: bez chyb před drobnou opravou čtečky historie; opravená self-host verze byla následně sestavena.
- 61 cenových testů bylo úspěšných před přidáním práce mechanika; nepokrývají tuto ani novou auditní funkci.
- 18 kontrol Node/SQLite runtime bylo úspěšných při dřívějším sestavení; po této změně nebyly znovu spuštěny.
- 21 HTTP kontrol bylo úspěšných při předchozím ověření self-host serveru; po následných změnách nebyly znovu spuštěny.

Ověření nezahrnuje konkrétní firemní infrastrukturu, její proxy a přístupová pravidla. Obchodní význam koeficientu, přetahu a zaokrouhlování vyžaduje potvrzení vlastníka podle NASAZENI.md.
