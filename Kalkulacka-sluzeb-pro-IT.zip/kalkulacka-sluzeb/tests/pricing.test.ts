import test from 'node:test';
import assert from 'node:assert/strict';
// Node 22 spouští tento test přímo přes --experimental-strip-types.
// @ts-ignore Přípona .ts je vyžadována nativním Node runnerem.
import { calculate, defaultConfig, defaultInput, validateConfig, validateInput } from '../lib/pricing.ts';
import type { PricingConfig, PricingInput, DomesticRegion, Region, Service } from '../lib/pricing';
const input = (patch: Partial<PricingInput> = {}): PricingInput => ({ ...defaultInput, ...patch });
const config = (): PricingConfig => structuredClone(defaultConfig);
const cases: [DomesticRegion, Service, number, number, number][] = [
  ['cz', 'standard', 1350, 1633.5, 25], ['cz', 'oversize', 1600, 1936, 27], ['cz', 'hydraulic', 2300, 2783, 28], ['cz', 'dpv', 1200, 1452, 19], ['cz', 'unlock', 2200, 2662, 19],
  ['cities', 'standard', 1550, 1875.5, 25], ['cities', 'oversize', 1800, 2178, 27], ['cities', 'hydraulic', 2550, 3085.5, 28], ['cities', 'dpv', 1300, 1573, 19], ['cities', 'unlock', 2200, 2662, 19],
  ['sk', 'standard', 58, 71.34, 1.05], ['sk', 'oversize', 70, 86.1, 1.15], ['sk', 'hydraulic', 95, 116.85, 1.2], ['sk', 'dpv', 48, 59.04, .8], ['sk', 'unlock', 88, 108.24, .8],
];
for (const [region, service, base, gross, km] of cases) {
  test(`Tarif ${region}/${service}: paušál, DPH, hranice, ekvivalentní režimy km`, () => {
    const limit = region === 'cities' ? 45 : 35;
    for (const distance of [0, 1, limit - 1, limit]) {
      const result = calculate(input({ region, service, distance }));
      assert.equal(result.net, base); assert.equal(result.gross, gross); assert.equal(result.extraKm, 0);
    }
    for (const extra of [1, 10, 100, .25]) {
      const total = calculate(input({ region, service, distance: limit + extra }));
      const manual = calculate(input({ region, service, distanceMode: 'extra', distance: extra }));
      assert.equal(total.net, Math.round((base + extra * km) * 100) / 100);
      const { summary: totalSummary, ...totalPrices } = total;
      const { summary: manualSummary, ...manualPrices } = manual;
      assert.deepEqual(totalPrices, manualPrices);
      assert.ok(totalSummary.includes('Celková trasa:'));
      assert.ok(manualSummary.includes('Manuálně zadané kilometry nad paušál:'));
    }
  });
}
for (const region of ['cz', 'cities', 'sk'] as DomesticRegion[]) {
  for (const [key, rate] of [['recoveryMinutes', region === 'sk' ? 36 : 900], ['manipulationMinutes', region === 'sk' ? 20 : 350], ['waitingMinutes', region === 'sk' ? 12 : 210]] as const) {
    test(`Každá půlhodina ${region}/${key}`, () => {
      for (let minutes = 0; minutes <= 300; minutes += 30) {
        const result = calculate(input({ region, [key]: minutes }));
        assert.equal(result.subtotal - result.base, rate * minutes / 30);
      }
    });
  }
  for (const coveredStorage of [false, true]) {
    test(`Každý den úschovy ${region}, krytá=${coveredStorage}`, () => {
      const rate = region === 'sk' ? (coveredStorage ? 7 : 6) : (coveredStorage ? 160 : 105);
      for (let storageDays = 0; storageDays <= 60; storageDays++) {
        const result = calculate(input({ region, storageDays, coveredStorage }));
        assert.equal(result.subtotal - result.base, storageDays * rate);
      }
    });
  }
  test(`Každý pevný doplněk ${region} a přepnutí vozíčků`, () => {
    const values = region === 'sk' ? [24, 14, 22, 32, 22] : [550, 300, 500, 750, 500];
    const patches: Partial<PricingInput>[] = [{ night: true }, { weekend: true }, { trolleys: 'one' }, { trolleys: 'multiple' }, { glasses: true }];
    patches.forEach((patch, i) => {
      const result = calculate(input({ region, ...patch }));
      assert.equal(result.subtotal - result.base, values[i]);
    });
    assert.equal(calculate(input({ region, night: true, weekend: true, trolleys: 'multiple', glasses: true })).subtotal, defaultConfig.regions[region].tariffs.standard.base + values[0] + values[1] + values[3] + values[4]);
  });
}
test('Živá reference CZ Standard 45 km, přidání a odebrání služby nezanechá částku', () => {
  const base = input({ distance: 45 });
  assert.equal(calculate(base).net, 1600); assert.equal(calculate(base).gross, 1936);
  assert.equal(calculate({ ...base, recoveryMinutes: 30 }).net, 2500);
  assert.deepEqual(calculate({ ...base, recoveryMinutes: 0 }), calculate(base));
  assert.equal(calculate({ ...base, night: true }).net, 2150);
});
test('Živá reference SK DPV, palivo a GOP; zachovaný násobek 1,20', () => {
  assert.equal(calculate(input({ region: 'sk', service: 'dpv' })).gross, 59.04);
  const result = calculate(input({ region: 'sk', service: 'dpv', fuel: true, gop: 1 }));
  assert.equal(result.fuel, 2.4); assert.equal(result.net, 50.4); assert.equal(result.vat, 11.59); assert.equal(result.gross, 61.99); assert.equal(result.clientPayment, 73.19);
});
test('Přetah samostatně přičte paušál a pouze své aktivní km', () => {
  const result = calculate(input({ transfer: true, transferExtraKm: 10 }));
  assert.equal(result.net, 1350 + 1350 + 250);
  assert.equal(calculate(input({ transfer: false, transferExtraKm: 10 })).net, 1350);
});
test('Mýto, jiná služba a text rozpisu; text není HTML', () => {
  const result = calculate(input({ toll: 120.25, otherName: '<script>test</script>', otherPrice: 10.5 }));
  assert.equal(result.net, 1480.75); assert.ok(result.summary.includes('<script>test</script>'));
  assert.equal(result.breakdown.filter((line: { id: string }) => line.id === 'other').length, 1);
});
test('Přepínání regionů nepřenáší paušál ani km limit', () => {
  calculate(input({ region: 'cities', distance: 45 }));
  const result = calculate(input({ region: 'cz', distance: 45 }));
  assert.equal(result.includedKm, 35); assert.equal(result.extraKm, 10); assert.equal(result.net, 1600);
});
test('Peníze: přesné půlení od nuly po položkách, palivu a DPH', () => {
  const cfg = config(); cfg.regions.cz.tariffs.standard = { base: 0, perKm: .01 }; cfg.regions.cz.vatPercent = 0;
  assert.equal(calculate(input({ distanceMode: 'extra', distance: .5 }), cfg).net, .01);
  cfg.regions.cz.tariffs.standard.base = 1350; cfg.fuelPercent = 5; cfg.regions.cz.vatPercent = 21;
  const result = calculate(input({ fuel: true }), cfg);
  assert.equal(result.net, 1417.5); assert.equal(result.vat, 297.68); assert.equal(result.gross, 1715.18);
  assert.equal(calculate(input({ gop: 2000 }), defaultConfig).clientPayment, 0);
});
test('Změna ceníku se projeví, původní objekt zůstává beze změn', () => {
  const cfg = config(); cfg.regions.cz.tariffs.standard.base = 100; cfg.regions.cz.tariffs.standard.perKm = 2; cfg.regions.cz.includedKm = 10; cfg.regions.cz.extras.night = 3;
  const before = JSON.stringify(cfg);
  assert.equal(calculate(input({ distance: 15, night: true }), cfg).net, 113);
  assert.equal(JSON.stringify(cfg), before); assert.equal(defaultConfig.regions.cz.tariffs.standard.base, 1350);
});
test('Validace chybějících, nekonečných, záporných a neplatných dat', () => {
  assert.deepEqual(validateConfig(defaultConfig), []); assert.deepEqual(validateInput(defaultInput), []);
  for (const bad of [null, {}, [], { ...defaultInput, distance: -1 }, { ...defaultInput, distance: NaN }, { ...defaultInput, gop: Infinity }, { ...defaultInput, region: 'XX' }, { ...defaultInput, waitingMinutes: 31 }, { ...defaultInput, storageDays: 61 }, { ...defaultInput, trolleys: 'both' }, { ...defaultInput, distance: .001 }, { ...defaultInput, otherPrice: 1 }]) {
    assert.ok(validateInput(bad).length > 0); assert.throws(() => calculate(bad as PricingInput));
  }
  for (const bad of [null, {}, { ...defaultConfig, fuelPercent: 101 }, { ...defaultConfig, clientPaymentMultiplier: -1 }, { ...defaultConfig, regions: { ...defaultConfig.regions, cz: { ...defaultConfig.regions.cz, tariffs: {} } } }]) assert.ok(validateConfig(bad).length > 0);
});

test('Editovatelné parametry: každá sazba regionu a tarifu má správný dopad', () => {
  const extraInputs: [string, Partial<PricingInput>][] = [
    ['recovery', { recoveryMinutes: 30 }], ['manipulation', { manipulationMinutes: 30 }], ['waiting', { waitingMinutes: 30 }], ['storage', { storageDays: 1 }], ['coveredStorage', { storageDays: 1, coveredStorage: true }], ['night', { night: true }], ['weekend', { weekend: true }], ['trolleyOne', { trolleys: 'one' }], ['trolleyMultiple', { trolleys: 'multiple' }], ['glasses', { glasses: true }],
  ];
  for (const region of ['cz', 'cities', 'sk'] as DomesticRegion[]) {
    for (const service of ['standard', 'oversize', 'hydraulic', 'dpv', 'unlock'] as Service[]) {
      const cfg = config();
      cfg.regions[region].tariffs[service].base += 1;
      assert.equal(calculate(input({ region, service }), cfg).net, calculate(input({ region, service })).net + 1);
      cfg.regions[region].tariffs[service].base -= 1;
      cfg.regions[region].tariffs[service].perKm += 1;
      assert.equal(calculate(input({ region, service, distanceMode: 'extra', distance: 2 }), cfg).net, calculate(input({ region, service, distanceMode: 'extra', distance: 2 })).net + 2);
    }
    for (const [key, patch] of extraInputs) {
      const cfg = config();
      const extras = cfg.regions[region].extras as unknown as Record<string, number>;
      extras[key] += 1;
      assert.equal(calculate(input({ region, ...patch }), cfg).net, calculate(input({ region, ...patch })).net + 1);
    }
    const cfg = config(); cfg.regions[region].includedKm += 1;
    assert.equal(calculate(input({ region, distance: cfg.regions[region].includedKm }), cfg).extraKm, 0);
    cfg.regions[region].vatPercent = 0;
    const result = calculate(input({ region }), cfg); assert.equal(result.vat, 0); assert.equal(result.gross, result.net);
  }
  const cfg = config(); cfg.fuelPercent = 0; cfg.clientPaymentMultiplier = 1;
  const result = calculate(input({ fuel: true, gop: 100 }), cfg);
  assert.equal(result.fuel, 0); assert.equal(result.clientPayment, result.gross - 100);
});


test('UZ: čitelný zápis CZ obsahuje trasu, položky, součty, GOP a doplatek', () => {
  const result = calculate(input({ distance: 45, recoveryMinutes: 60, fuel: true, gop: 1000, otherName: '  Speciální\nslužba\tpo zásahu  ', otherPrice: 50 }));
  assert.equal(result.summary, [
    'KALKULACE SLUŽEB',
    'Region: CZ',
    'Služba: RMQ · Standard',
    'Celková trasa: 45 km',
    'Paušál zahrnuje: 35 km',
    'Účtované kilometry nad paušál: 10 km',
    '',
    'POLOŽKY BEZ DPH',
    'Paušál · RMQ · Standard: 1 350,00 Kč',
    'Kilometry nad paušál: 10 × 25,00 Kč = 250,00 Kč',
    'Vyproštění (30 minut): 2 × 900,00 Kč = 1 800,00 Kč',
    'Speciální služba po zásahu: 50,00 Kč',
    '',
    'Součet služeb: 3 450,00 Kč',
    'Palivový příplatek (5 %): 172,50 Kč',
    'Celkem bez DPH: 3 622,50 Kč',
    'DPH (21 %): 760,73 Kč',
    'CELKEM S DPH: 4 383,23 Kč',
    '',
    'GOP – hrazená částka: 1 000,00 Kč',
    'Doplatek klientovi (koeficient 1,20): 4 059,88 Kč',
  ].join('\n'));
  assert.ok(!result.summary.includes('//'));
  assert.ok(!result.summary.includes('\t'));
});

test('UZ: slovenská měna a manuální kilometry jsou jasně označené', () => {
  const result = calculate(input({ region: 'sk', service: 'dpv', distanceMode: 'extra', distance: 2.5, gop: 10 }));
  assert.ok(result.summary.includes('Region: SK\nSlužba: DPV'));
  assert.ok(result.summary.includes('Manuálně zadané kilometry nad paušál: 2,5 km'));
  assert.ok(result.summary.includes('Kilometry nad paušál: 2,5 × 0,80 € = 2,00 €'));
  assert.ok(result.summary.includes('Palivový příplatek: neúčtován'));
  assert.ok(result.summary.includes('CELKEM S DPH: 61,50 €'));
  assert.ok(result.summary.endsWith('Doplatek klientovi (koeficient 1,20): 61,80 €'));
  assert.ok(!result.summary.includes('Kč'));
  assert.ok(!result.summary.includes('Celková trasa:'));
});

for (const [region, currency, vatPercent] of [['abroad_cz', 'CZK', 21], ['abroad_sk', 'EUR', 23]] as const) {
  test(`Zahraničí ${region}: výchozí sazby jsou nuly a konfigurace nepotřebuje migraci`, () => {
    const before = config();
    assert.deepEqual(validateConfig(before), []);
    for (const abroadMode of ['flat', 'hourly'] as const) {
      const result = calculate(input({ region, abroadMode, distance: 1000, abroadHours: 10 }), before);
      assert.equal(result.currency, currency);
      assert.equal(result.net, 0); assert.equal(result.gross, 0); assert.equal(result.base, 0); assert.equal(result.perKm, 0);
      assert.equal(result.includedKm, 0); assert.equal(result.extraKm, 1000);
    }
    assert.deepEqual(before, defaultConfig);
    assert.deepEqual(Object.keys(before.regions).sort(), ['cities', 'cz', 'sk']);
  });
  test(`Zahraničí ${region}: paušál a všechny kilometry bez odečtu limitu`, () => {
    const result = calculate(input({ region, abroadFlatRate: 1000, abroadPerKm: 2.5, distance: 40, gop: 100 }));
    assert.equal(result.subtotal, 1100); assert.equal(result.net, 1100);
    assert.equal(result.vat, 1100 * vatPercent / 100); assert.equal(result.gross, 1100 * (100 + vatPercent) / 100);
    assert.equal(result.extraKm, 40); assert.equal(result.includedKm, 0);
    assert.deepEqual(result.breakdown.map(x => [x.id, x.quantity, x.unitPrice, x.total]), [['base', 1, 1000, 1000], ['distance', 40, 2.5, 100]]);
    assert.ok(result.summary.includes(`Region: ${region === 'abroad_cz' ? 'Zahraničí CZ' : 'Zahraničí SK'}`));
    assert.ok(result.summary.includes('Režim: Paušál'));
    assert.ok(result.summary.includes('Celková trasa: 40 km'));
    assert.ok(!result.summary.includes('RMQ')); assert.ok(!result.summary.includes('nad paušál')); assert.ok(!result.summary.includes('Paušál zahrnuje:'));
  });
  test(`Zahraničí ${region}: hodiny krát sazba plus všechny km a jiná služba`, () => {
    const result = calculate(input({ region, abroadMode: 'hourly', abroadHourlyRate: 100, abroadHours: 2.5, abroadPerKm: 2, distance: 10, otherName: 'Poplatek za trajekt', otherPrice: 30, abroadFlatRate: 99999 }));
    assert.equal(result.subtotal, 300); assert.equal(result.base, 250);
    assert.equal(result.vat, 300 * vatPercent / 100);
    assert.deepEqual(result.breakdown.map(x => [x.id, x.quantity, x.unitPrice, x.total]), [['hourly', 2.5, 100, 250], ['distance', 10, 2, 20], ['other', 1, 30, 30]]);
    assert.ok(result.summary.includes('Režim: Hodinová sazba')); assert.ok(result.summary.includes('Počet hodin: 2,5 h'));
    assert.ok(result.summary.includes('Práce — hodinová sazba: 2,5 ×'));
    assert.ok(result.summary.includes('DPH (' + vatPercent + ' %)'));
    assert.ok(!result.summary.includes(currency === 'CZK' ? '€' : 'Kč'));
    assert.equal(calculate(input({ region, abroadMode: 'hourly', abroadHours: 0, abroadHourlyRate: 100 })).net, 0);
  });
  test(`Zahraničí ${region}: skryté domácí služby, palivo a neaktivní tarif se neúčtují`, () => {
    const plain = input({ region, abroadFlatRate: 100, abroadPerKm: 1, distance: 10 });
    const stale = { ...plain, service: 'unlock' as const, distanceMode: 'extra' as const, recoveryMinutes: 300, manipulationMinutes: 300, waitingMinutes: 300, storageDays: 60, coveredStorage: true, night: true, weekend: true, trolleys: 'multiple' as const, glasses: true, transfer: true, transferExtraKm: 1000, toll: 10000, fuel: true, abroadHourlyRate: 9999, abroadHours: 9999 };
    assert.deepEqual(calculate(stale), calculate(plain));
    assert.equal(calculate(stale).fuel, 0);
  });
  test(`Zahraničí ${region}: DPH a měna sledují odpovídající uložený ceník`, () => {
    const pricing = config();
    pricing.regions[region === 'abroad_cz' ? 'cz' : 'sk'].vatPercent = 15;
    const result = calculate(input({ region, abroadFlatRate: 100 }), pricing);
    assert.equal(result.vat, 15); assert.equal(result.gross, 115); assert.equal(result.currency, currency);
  });
}

test('Zahraničí: validace sazeb, hodin a režimu; starý domácí vstup zůstává platný', () => {
  const legacy = { ...defaultInput } as Record<string, unknown>;
  for (const key of ['abroadMode', 'abroadFlatRate', 'abroadHourlyRate', 'abroadHours', 'abroadPerKm']) delete legacy[key];
  assert.deepEqual(validateInput(legacy), []);
  for (const key of ['abroadFlatRate', 'abroadHourlyRate', 'abroadHours', 'abroadPerKm'] as const) {
    for (const value of [-1, NaN, Infinity, 1000001, 1.001, '10']) {
      assert.ok(validateInput({ ...defaultInput, region: 'abroad_cz', [key]: value }).length > 0, `${key}/${value}`);
      assert.deepEqual(validateInput({ ...defaultInput, [key]: value }), [], `Domácí vstup ignoruje ${key}/${value}`);
    }
  }
  assert.ok(validateInput({ ...defaultInput, region: 'abroad_sk', abroadMode: 'invalid' }).length > 0);
  assert.ok(validateInput({ ...defaultInput, region: 'abroad_sk', otherPrice: 10, otherName: '' }).length > 0);
  assert.deepEqual(validateInput({ ...defaultInput, region: 'abroad_sk', service: 'ignored', distanceMode: 'ignored', toll: -100, night: 'ignored' }), []);
});

test('Zahraničí: návrat do domácího regionu nepřenáší ručně zadané sazby', () => {
  const domestic = input({ region: 'cz', distance: 45 });
  const withStaleRates = { ...domestic, abroadMode: 'hourly' as const, abroadFlatRate: 10000, abroadHourlyRate: 999, abroadHours: 99, abroadPerKm: 100 };
  assert.deepEqual(calculate(withStaleRates), calculate(domestic));
});


for (const [region, gross, abroadFlatRate] of [['cz', 1633.5, 0], ['sk', 71.34, 0], ['abroad_cz', 121, 100], ['abroad_sk', 123, 100]] as const) {
  test(`Doplatek ${region}: pouze kladná částka při GOP pod, rovno a nad cenou`, () => {
    const base = input({ region, abroadFlatRate });
    assert.equal(calculate(base).gross, gross);
    const payable = calculate({ ...base, gop: Math.round((gross - .01) * 100) / 100 });
    assert.equal(payable.clientPayment, .01);
    assert.ok(payable.summary.includes('Doplatek klientovi (koeficient 1,20): 0,01'));
    for (const gop of [gross, gross + 100]) {
      const covered = calculate({ ...base, gop });
      assert.equal(covered.clientPayment, 0);
      assert.ok(!covered.summary.includes('Doplatek klientovi'));
      assert.equal(covered.gross, gross);
      assert.ok(covered.summary.includes('GOP – hrazená částka:'));
    }
  });
}
test('Doplatek po zaokrouhlení na nulu není v UZ', () => {
  const cfg = config(); cfg.clientPaymentMultiplier = .1;
  const result = calculate(input({ gop: 1633.49 }), cfg);
  assert.equal(result.clientPayment, 0);
  assert.ok(!result.summary.includes('Doplatek klientovi'));
});
