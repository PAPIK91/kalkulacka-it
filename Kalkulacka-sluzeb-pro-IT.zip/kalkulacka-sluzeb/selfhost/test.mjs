import assert from 'node:assert/strict';
import {mkdtempSync,readFileSync,existsSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {randomBytes} from 'node:crypto';
const temp=mkdtempSync(join(tmpdir(),'axa-selfhost-test-'));process.env.DATA_DIR=temp;
const {context,finishSetup,closeDb}=await import('./dist/runtime.mjs');
const api=await import('./dist/api.mjs');
const origin='http://localhost:4328';let cookie='';let checks=0;
async function call(handler,method,path,body,token=''){const req=new Request(origin+path,{method,headers:{Origin:origin,'Content-Type':'application/json',...(cookie?{Cookie:cookie}:{}),...(token?{'X-Setup-Token':token}:{})},...(body?{body:JSON.stringify(body)}:{})});return context.run(req,()=>handler(req));}
try{
 const seeded=structuredClone((await (await call(api.getConfig,'GET','/api/config')).json()).config);seeded.fuelPercent=6;assert.equal(await api.initializeConfig(seeded),true);checks++;
 const token=readFileSync(join(temp,'setup-token'),'utf8');const password=randomBytes(24).toString('hex');
 assert.equal(token.length,64);checks++;
 let response=await call(api.getConfig,'GET','/api/config');let config=await response.json();assert.equal(config.setupAvailable,false);assert.equal(config.admin,false);checks+=2;
 response=await call(api.auth,'POST','/api/auth',{action:'setup',password});assert.equal(response.status,403);checks++;
 response=await call(api.auth,'POST','/api/auth',{action:'setup',password},token);assert.equal(response.status,200);cookie=response.headers.get('set-cookie').split(';')[0];checks++;
 finishSetup();assert.equal(existsSync(join(temp,'setup-token')),false);checks++;
 response=await call(api.getConfig,'GET','/api/config');config=await response.json();assert.equal(config.admin,true);assert.equal(config.setupRequired,false);assert.equal(config.setupAvailable,false);assert.equal(config.config.fuelPercent,6);assert.equal(await api.initializeConfig({...seeded,fuelPercent:7}),false);checks+=5;
 response=await call(api.auth,'POST','/api/auth',{action:'logout'});assert.equal(response.status,200);checks++;
 response=await call(api.putConfig,'PUT','/api/config',{config:config.config,version:config.version});assert.equal(response.status,401);checks++;
 cookie='';response=await call(api.auth,'POST','/api/auth',{action:'login',password});assert.equal(response.status,200);cookie=response.headers.get('set-cookie').split(';')[0];checks++;
 response=await call(api.putConfig,'PUT','/api/config',{config:config.config,version:config.version});assert.equal(response.status,200);checks++;
 response=await call(api.putConfig,'PUT','/api/config',{config:config.config,version:config.version});assert.equal(response.status,409);checks++;
 response=await call(api.auth,'POST','/api/auth',{action:'setup',password},token);assert.equal(response.status,403);checks++;
 console.log(`${checks} kontrol self-host runtime prošlo (stejné API, SQLite, jednorázový setup, relace, verze).`);
}finally{closeDb();rmSync(temp,{recursive:true,force:true});}
