import {createServer} from 'node:http';
import {readFile,stat} from 'node:fs/promises';
import {resolve,dirname,extname,sep} from 'node:path';
import {fileURLToPath} from 'node:url';
import {context,finishSetup,closeDb} from './runtime.mjs';
import * as api from './api.mjs';
const here=dirname(fileURLToPath(import.meta.url));
const initialConfigPath=resolve(process.env.DATA_DIR||'./data','initial-config.json');
try{const seeded=JSON.parse(await readFile(initialConfigPath,'utf8'));await api.initializeConfig(seeded.config??seeded);}catch(error){if(error.code!=='ENOENT')throw error;}
const client=resolve(here,'client');
const host=process.env.HOST||'127.0.0.1';
const port=Number(process.env.PORT||3000);
const publicOrigin=process.env.PUBLIC_ORIGIN?new URL(process.env.PUBLIC_ORIGIN).origin:null;
const routes={'GET /api/config':api.getConfig,'PUT /api/config':api.putConfig,'POST /api/auth':api.auth,'POST /api/calculate':api.calculate};
const types={'.html':'text/html; charset=utf-8','.js':'application/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.ico':'image/x-icon','.woff2':'font/woff2'};
const server=createServer(async(req,res)=>{try{
 if(!/^\/(?!\/)/.test(req.url||'')){res.writeHead(400);return res.end('Bad request target');}
 const authority=req.headers.host||'';
 if(!/^[a-zA-Z0-9.:[\]-]+$/.test(authority)){res.writeHead(400);return res.end('Bad host');}
 const origin=publicOrigin||`http://${authority}`;
 const url=new URL(req.url||'/',origin);
 const method=req.method||'GET';
 const headers=new Headers();for(const [key,value] of Object.entries(req.headers)){if(value!==undefined)headers.set(key,Array.isArray(value)?value.join(', '):value);}
 const security={'X-Content-Type-Options':'nosniff','Referrer-Policy':'same-origin','X-Frame-Options':'DENY'};
 if(url.pathname.startsWith('/api/')){
  const handler=routes[`${method} ${url.pathname}`];if(!handler){res.writeHead(405,{'Content-Type':'application/json',...security});return res.end(JSON.stringify({error:'Nepovolená operace.'}));}
  let size=0;const chunks=[];for await(const chunk of req){size+=chunk.length;if(size>64000){res.writeHead(413,security);return res.end('Příliš velký požadavek.');}chunks.push(chunk);}
  const data=Buffer.concat(chunks);const request=new Request(url,{method,headers,...(data.length?{body:data}:{} )});
  const response=await context.run(request,()=>handler(request));
  const responseHeaders={...security};response.headers.forEach((value,key)=>{if(key!=='set-cookie')responseHeaders[key]=value;});const cookies=response.headers.getSetCookie();if(cookies.length)responseHeaders['set-cookie']=cookies;
  if(url.pathname==='/api/auth'&&response.ok)finishSetup();
  res.writeHead(response.status,responseHeaders);return res.end(Buffer.from(await response.arrayBuffer()));
 }
 if(method!=='GET'&&method!=='HEAD'){res.writeHead(405,security);return res.end();}
 const decoded=decodeURIComponent(url.pathname);let file=resolve(client,`.${decoded}`);
 if(file!==client&&!file.startsWith(client+sep)){res.writeHead(403,security);return res.end();}
 try{if(!(await stat(file)).isFile())file=resolve(client,'index.html');}catch{file=resolve(client,'index.html');}
 const bytes=await readFile(file);res.writeHead(200,{'Content-Type':types[extname(file)]||'application/octet-stream','Cache-Control':file.includes(`${sep}assets${sep}`)?'public, max-age=31536000, immutable':'no-cache',...security});res.end(method==='HEAD'?undefined:bytes);
 }catch{if(!res.headersSent)res.writeHead(500,{'Content-Type':'application/json'});res.end(JSON.stringify({error:'Požadavek se nepodařilo dokončit.'}));}});
server.requestTimeout=30000;server.headersTimeout=15000;
server.listen(port,host,()=>console.log(`Kalkulačka naslouchá na ${host}:${port}`));
for(const signal of ['SIGTERM','SIGINT'])process.on(signal,()=>server.close(()=>{closeDb();process.exit(0);}));
