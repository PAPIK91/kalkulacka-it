import {DatabaseSync} from 'node:sqlite';
import {mkdirSync,existsSync,readFileSync,writeFileSync,unlinkSync} from 'node:fs';
import {resolve} from 'node:path';
import {randomBytes,timingSafeEqual} from 'node:crypto';
import {AsyncLocalStorage} from 'node:async_hooks';
process.umask(0o077);
export const context=new AsyncLocalStorage();
export const dataDir=resolve(process.env.DATA_DIR||'./data');
mkdirSync(dataDir,{recursive:true,mode:0o700});
const db=new DatabaseSync(resolve(dataDir,'pricing.sqlite'));
db.exec(`PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000;
CREATE TABLE IF NOT EXISTS settings(id INTEGER PRIMARY KEY,config TEXT NOT NULL,version INTEGER NOT NULL,owner_id TEXT NOT NULL,password_hash TEXT NOT NULL,salt TEXT NOT NULL,failures INTEGER NOT NULL DEFAULT 0,locked_until INTEGER NOT NULL DEFAULT 0,updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY,owner_id TEXT NOT NULL,expires_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS price_audit(id INTEGER PRIMARY KEY AUTOINCREMENT,actor TEXT NOT NULL,changed_at TEXT NOT NULL,version INTEGER NOT NULL,changes TEXT NOT NULL);`);
const setupPath=resolve(dataDir,'setup-token');
if(!db.prepare('SELECT id FROM settings WHERE id=1').get()&&!existsSync(setupPath))writeFileSync(setupPath,randomBytes(32).toString('hex'),{mode:0o600,flag:'wx'});
function token(){try{return readFileSync(setupPath,'utf8').trim();}catch{return '';}}
function validSetup(){const candidate=context.getStore()?.headers.get('x-setup-token')||'';const expected=token();return candidate.length===64&&expected.length===64&&timingSafeEqual(Buffer.from(candidate),Buffer.from(expected));}
export function finishSetup(){if(db.prepare('SELECT id FROM settings WHERE id=1').get()&&existsSync(setupPath))unlinkSync(setupPath);}
class Prepared {
 constructor(sql,params=[]){this.sql=sql;this.params=params;}
 bind(...params){return new Prepared(this.sql,params);}
 async all(){return {success:true,results:db.prepare(this.sql).all(...this.params)};}
 async first(){return db.prepare(this.sql).get(...this.params)??null;}
 async run(){const result=db.prepare(this.sql).run(...this.params);return {success:true,meta:{changes:Number(result.changes),last_row_id:Number(result.lastInsertRowid)}};}
}
export const env={DB:{prepare:sql=>new Prepared(sql)},get ALLOW_ADMIN_SETUP(){return token()?'true':'false';}};
env.DB.batch=async statements=>{
 db.exec('BEGIN IMMEDIATE');
 try{
  const results=statements.map(statement=>{const result=db.prepare(statement.sql).run(...statement.params);return {success:true,meta:{changes:Number(result.changes),last_row_id:Number(result.lastInsertRowid)}};});
  db.exec('COMMIT');return results;
 }catch(error){db.exec('ROLLBACK');throw error;}
};
export async function getChatGPTUser(){return validSetup()?{userId:'selfhost-owner',email:'owner@localhost',displayName:'Správce',fullName:null}:null;}
export function closeDb(){db.close();}
