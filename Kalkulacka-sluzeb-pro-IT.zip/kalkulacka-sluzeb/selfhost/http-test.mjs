import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {mkdtempSync,readFileSync,writeFileSync,existsSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {randomBytes} from 'node:crypto';
import {request as rawRequest} from 'node:http';
import {defaultConfig} from '../lib/pricing.ts';
const dir=mkdtempSync(join(tmpdir(),'axa-selfhost-http-'));const origin='http://127.0.0.1:4328';
const seeded=structuredClone(defaultConfig);seeded.fuelPercent=6;writeFileSync(join(dir,'initial-config.json'),JSON.stringify(seeded));
const server=spawn(process.execPath,[fileURLToPath(new URL('dist/server.mjs',import.meta.url))],{env:{...process.env,DATA_DIR:dir,PORT:'4328',HOST:'127.0.0.1',PUBLIC_ORIGIN:origin},stdio:['ignore','pipe','pipe']});let log='';server.stdout.on('data',b=>log+=b);server.stderr.on('data',b=>log+=b);
let cookie='';let checks=0;
async function req(path,method='GET',data,headers={}){return fetch(origin+path,{method,headers:{Origin:origin,'Content-Type':'application/json',...(cookie?{Cookie:cookie}:{}),...headers},...(data?{body:JSON.stringify(data)}:{}),signal:AbortSignal.timeout(5000)});}
async function target(path){return new Promise((resolve,reject)=>{const request=rawRequest(origin,{path},response=>{response.resume();response.on('end',()=>resolve(response.statusCode));});request.on('error',reject);request.end();});}
try{
 for(let i=0;i<40;i++){if(log.includes('naslouchá'))break;if(server.exitCode!==null)throw Error(log);await new Promise(r=>setTimeout(r,100));}
 let response=await req('/');assert.equal(response.status,200);assert.match(await response.text(),/Kalkulačka služeb/);checks++;
 response=await req('/api/config');let data=await response.json();assert.equal(data.config.fuelPercent,6);assert.equal(data.setupAvailable,false);assert.equal(data.admin,false);checks+=3;
 const password=randomBytes(24).toString('hex');
 response=await req('/api/auth','POST',{action:'setup',password},{'oai-authenticated-user-id':'spoof','oai-authenticated-user-email':'spoof@example.invalid'});assert.equal(response.status,403);checks++;
 response=await req('/api/auth','POST',{action:'setup',password},{'X-Setup-Token':'x'.repeat(64)});assert.equal(response.status,403);checks++;
 const token=readFileSync(join(dir,'setup-token'),'utf8');response=await req('/api/config','GET',undefined,{'X-Setup-Token':token});data=await response.json();assert.equal(data.setupAvailable,true);checks++;
 response=await req('/api/auth','POST',{action:'setup',password},{'X-Setup-Token':token,Origin:'http://evil.invalid'});assert.equal(response.status,403);checks++;
 response=await req('/api/auth','POST',{action:'setup',password},{'X-Setup-Token':token});assert.equal(response.status,200);cookie=response.headers.get('set-cookie').split(';')[0];assert.equal(existsSync(join(dir,'setup-token')),false);checks+=2;
 response=await req('/api/config');data=await response.json();assert.equal(data.admin,true);assert.equal(data.config.fuelPercent,6);checks+=2;
 response=await req('/api/config','PUT',{config:{...data.config,fuelPercent:7},version:data.version});assert.equal(response.status,200);checks++;
 response=await req('/api/auth','POST',{action:'logout'});assert.equal(response.status,200);checks++;
 response=await req('/api/config','PUT',{config:data.config,version:data.version});assert.equal(response.status,401);checks++;
 cookie='';response=await req('/api/auth','POST',{action:'login',password});assert.equal(response.status,200);cookie=response.headers.get('set-cookie').split(';')[0];checks++;
 response=await req('/api/config','PUT',{config:data.config,version:data.version},{Origin:'http://evil.invalid'});assert.equal(response.status,403);checks++;
 response=await req('/..%2f..%2fetc%2fpasswd');assert.equal(response.status,403);checks++;
 assert.equal(await target('http://evil.invalid/api/config'),400);assert.equal(await target('//evil.invalid/api/config'),400);checks+=2;
 response=await req('/api/config');data=await response.json();assert.equal(data.config.fuelPercent,7);checks++;
 console.log(`${checks} HTTP kontrol self-host serveru prošlo.`);
}finally{server.kill('SIGTERM');await new Promise(r=>server.once('exit',r));rmSync(dir,{recursive:true,force:true});}
