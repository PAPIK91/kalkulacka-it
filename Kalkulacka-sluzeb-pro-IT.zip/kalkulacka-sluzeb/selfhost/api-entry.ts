export {GET as getConfig,PUT as putConfig} from '../app/api/config/route';
export {POST as auth} from '../app/api/auth/route';
export {POST as calculate} from '../app/api/calculate/route';
import {defaultConfig,validateConfig} from '../lib/pricing';
import {settings} from '../lib/server-pricing';
export async function initializeConfig(value:unknown){
 if(await settings())return false;
 const errors=validateConfig(value);if(errors.length)throw new Error('Neplatný počáteční ceník: '+errors.join(' '));
 Object.assign(defaultConfig,structuredClone(value));return true;
}
