export {GET as getConfig,PUT as putConfig} from '../app/api/config/route';
export {POST as auth} from '../app/api/auth/route';
export {POST as calculate} from '../app/api/calculate/route';
import {defaultConfig,upgradeConfig,validateConfig} from '../lib/pricing';
import {settings} from '../lib/server-pricing';
export async function initializeConfig(value:unknown){
 if(await settings())return false;
 const config=upgradeConfig(value);const errors=validateConfig(config);if(errors.length)throw new Error('Neplatný počáteční ceník: '+errors.join(' '));
 Object.assign(defaultConfig,structuredClone(config));return true;
}
