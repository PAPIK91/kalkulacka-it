import React from 'react';
import { createRoot } from 'react-dom/client';
import Home from '../app/page';
import '../app/globals.css';
// The one-time setup token stays in memory and is never sent in the URL or persisted.
const fragment=new URLSearchParams(location.hash.slice(1));
let setupToken=fragment.get('setup')||'';
if(setupToken){history.replaceState(null,'',location.pathname+location.search);const nativeFetch=window.fetch.bind(window);window.fetch=async(input,init)=>{const url=new URL(input instanceof Request?input.url:String(input),location.href);if(url.origin===location.origin&&['/api/config','/api/auth'].includes(url.pathname)){const headers=new Headers(init?.headers||(input instanceof Request?input.headers:undefined));headers.set('X-Setup-Token',setupToken);const response=await nativeFetch(input,{...init,headers});if(url.pathname==='/api/auth'&&response.ok){setupToken='';}return response;}return nativeFetch(input,init);};}
createRoot(document.getElementById('root')!).render(<React.StrictMode><Home/></React.StrictMode>);
