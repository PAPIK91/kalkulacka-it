# Nasazení na vlastní server

Používá stejné React rozhraní, výpočty i API handlery jako Sites. Adaptér nahrazuje D1 lokální SQLite a platformní identitu pouze jednorázovým nastavením hesla. Běžná kalkulačka je veřejná, administrace vyžaduje heslo.

```sh
node selfhost/build.mjs
node selfhost/test.mjs
docker build -t axa-kalkulacka selfhost
```

Runtime vyžaduje Node.js 24 nebo novější. Výstup `selfhost/dist/` nemá externí runtime závislosti; obsahuje server, sdílené API a statické soubory. Docker používá oficiální `node:24-bookworm-slim` a uživatele `node`.

Příklad spuštění za Caddy:

```sh
docker volume create axa-kalkulacka-data
docker run -d --name axa-kalkulacka --restart unless-stopped -p 127.0.0.1:3000:3000 -e PUBLIC_ORIGIN=https://kalkulacka.example.cz -v axa-kalkulacka-data:/data axa-kalkulacka
```

`PUBLIC_ORIGIN` musí odpovídat adrese v prohlížeči; používá se pro kontrolu původu požadavků i Secure cookie. Forwarded hlavičky se nepřebírají od klienta. Port Node nezpřístupňujte přímo internetu, TLS zajišťuje Caddy. `HOST` má mimo Docker výchozí `127.0.0.1`, `PORT` výchozí `3000`, `DATA_DIR` výchozí `./data`.

## První nastavení

Při prázdné databázi vznikne `/data/setup-token` s právy 0600. Token se nevypisuje do logu. Vlastník jej jednorázově získá z chráněného serverového úložiště a otevře `https://kalkulacka.example.cz/#setup=TOKEN`. Fragment se odstraní z adresního řádku a token se uchovává pouze v paměti stránky pro setup požadavky. Ve Správě ceníku vlastník sám zadá heslo. Po úspěšném nastavení se tokenový soubor smaže; původní token již nelze použít a veřejný návštěvník heslo nastavit nemůže.

Správce ze Sites ani jeho heslo nejsou součástí zdrojového kódu a nepřenášejí se do nové databáze. Před nasazením je třeba ověřit, zda má být převeden také případně upravený ceník. Výchozí ceny jsou stejné jako v aplikaci.

## Data a zálohy

Ceník, hash hesla a relace jsou v `/data/pricing.sqlite` (SQLite WAL). Zachovejte Docker volume při aktualizaci a databázi pravidelně zálohujte konzistentním SQLite backupem. Smazání volume znamená ztrátu ceníku i přístupu správce. Hesla ani tokeny neukládejte do Dockerfile, repozitáře nebo příkazových argumentů.

`selfhost/test.mjs` vytváří a odstraňuje pouze jednorázovou dočasnou databázi. Ověřuje 15 případů včetně setup tokenu, anonymní kalkulačky, heslové relace, nepovoleného zápisu, odhlášení a souběžných verzí.

Dalších 21 skutečných HTTP kontrol ověřuje `node --experimental-strip-types selfhost/http-test.mjs`. HTTP test používá pouze izolovanou dočasnou databázi a lokální port 4328. Přenesený ceník může být v `/data/initial-config.json` (samotný objekt nebo odpověď `{config: ...}`). Validuje se sdíleným validátorem a použije se pouze před prvním nastavením; existující ceník se při restartu nepřepisuje.
