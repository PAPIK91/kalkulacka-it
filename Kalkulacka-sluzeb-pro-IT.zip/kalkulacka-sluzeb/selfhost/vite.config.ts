import {defineConfig} from 'vite';
import react from '@vitejs/plugin-react';
import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('.',import.meta.url));
export default defineConfig({root,plugins:[react()],publicDir:'../public',resolve:{alias:{'@':fileURLToPath(new URL('..',import.meta.url))}},build:{outDir:'dist/client',emptyOutDir:true}});
