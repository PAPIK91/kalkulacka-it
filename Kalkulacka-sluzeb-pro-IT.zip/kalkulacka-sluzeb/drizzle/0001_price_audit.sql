CREATE TABLE `price_audit` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`actor` text NOT NULL,
	`changed_at` text NOT NULL,
	`version` integer NOT NULL,
	`changes` text NOT NULL
);
