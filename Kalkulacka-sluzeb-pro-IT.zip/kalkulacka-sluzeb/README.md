# Kalkulačka služeb — předání IT

Projekt obsahuje veřejnou webovou kalkulačku a správu ceníku chráněnou heslem. Pro vlastní server použijte variantu `selfhost/`; přihlášení přes ChatGPT ani provoz Sites nejsou potřeba.

- **Nasazení:** postup v `NASAZENI.md`; připravené `docker-compose.yml`, `.env.example` a `Caddyfile.example`.
- **Sestavení a testy:** `npm ci`, `npm run build`, `npm test`, `npm run test:selfhost`.
- **Zdroj výpočtů a výchozích cen:** `lib/pricing.ts`.
- **Uživatelské rozhraní:** `app/page.tsx`, `app/globals.css`.
- **Sdílená API:** `app/api/`; přenosná vrstva Node/SQLite v `selfhost/`.
- **Hotový runtime:** `selfhost/dist/` je součástí předaného balíčku. Lze jej znovu sestavit ze zdrojů.

Předání neobsahuje produkční databázi, heslo správce, jeho hash, relační cookies ani jednorázový nastavovací token. Nový správce si vytvoří vlastní heslo. Výchozí ceník je součástí projektu; přenos upraveného ceníku je samostatný krok.

Před ostrým použitím vlastník potvrdí obchodní význam koeficientu doplatku 1,20, pravidla přetahu a zaokrouhlování. Technické testy nenahrazují schválení cenových pravidel.

Aktualizace této verze: kopírovaný rozpis UZ má přehledný víceřádkový formát zápisu do případu — služba, trasa, položky, DPH, GOP a doplatek.

## Aktuální funkce

- U DPV a Odemčení vozidla položky manipulace, vyproštění, ztížená manipulace, čekání a úschova nahrazuje práce mechanika na místě po každých započatých 30 minutách. Sazby jsou oddělené pro obě služby a každý region, v ceníku výchozí 0; starší ceník se při načtení doplní bez zásahu do ostatních cen.

- U služeb DPV a Odemčení vozidla položky manipulace, vyproštění, ztížená manipulace, čekání a úschova nahrazuje práce mechanika na místě po každých započatých 30 minutách. Sazby jsou samostatné pro každou službu a region, v ceníku výchozí 0. U ostatních služeb dosavadní položky zůstávají.

- Regiony Zahraničí CZ a Zahraničí SK přebírají měnu a DPH z odpovídajícího CZ/SK ceníku. Operátor zadává paušál nebo hodinovou sazbu a počet hodin, vlastní cenu za kilometr a případně jinou službu. Výchozí ruční sazby jsou 0; účtuje se celá zadaná trasa bez kilometrů zahrnutých v paušálu. Jiné domácí služby a příplatky se v zahraničí neúčtují.
- Doplatek je nejméně 0 a v souhrnu i UZ se zobrazuje pouze při kladné částce.
- Texty a popisky mají mírně zvýšený kontrast.
