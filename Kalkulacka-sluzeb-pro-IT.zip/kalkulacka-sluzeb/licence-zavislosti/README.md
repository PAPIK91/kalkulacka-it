# Licence závislostí

Přiložené licence se vztahují na příslušné závislosti, nikoli automaticky na vlastní kód kalkulačky. Úplný seznam a přesné verze vývojových závislostí jsou v package-lock.json; jejich licence jsou také součástí příslušných npm balíčků. Runtime obraz používá oficiální Node.js image, jehož licence a aktualizace spravuje IT podle interních pravidel.
